-- The Musical Hop
INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (1, 1, '2020-05-21T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (1, 2, '2020-05-22T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (1, 3, '2020-05-23T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (1, 3, '2019-05-21T21:30:00.000Z');

-- The Dueling Pianos Bar
INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (2, 1, '2020-06-21T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (2, 2, '2020-06-22T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (2, 3, '2020-06-23T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (2, 3, '2019-06-21T21:30:00.000Z');

-- Park Square Live Music & Coffee
INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (3, 1, '2020-07-21T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (3, 2, '2020-07-22T21:30:00.000Z');

INSERT INTO "shows"(venue_id, artist_id, start_time)
VALUES (3, 3, '2020-07-23T21:30:00.000Z');